python3 server.py & python -m main.py
